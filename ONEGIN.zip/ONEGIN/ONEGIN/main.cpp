/**
> file >    main.cpp
> authors > Mitya Beldii & Denis Narcev, GROUP 672
> date >    OCTOBER 31, 2016
 **/

#define _CRT_NONSTDC_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#include <cassert>
#include <io.h>
#include <locale>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
DOWN 	- used to sort from the begin to end;
UP 	- used to sort from the end to begin;
OK	- returned to show that the programm is running corretly;
ERROR	- returned to show that the programm is running uncorretly;
FIRST - used to sort text by first letters in each string;
LAST 	- used to sort text by last  letters in each string;
**/

enum {DOWN = 'DOWN', UP = 'UP', OK = 1, ERROR = -1, FIRST = 'FIRS', LAST = 'LAST'};


/**
@function getString
This is our intepritation of fread function combined with closing file;
	FILE* 		  - is file with the text we want to sort;
	char buffer[] - is dynamic array of letters, numbers, and other symbols including a symbol of the transition to a new line;
	int* length   - length of input file (length = filelength(fileno(*FILENAME*)));
return - only OK;

countLines - is function that returned number of lines in the input file, with checking if the last symdol is not a symbol of the transition to a new line;
	char buffer[] - is our buffer getString function contained the text including symdols of the transition to a new line;
	char symbol   - is symbol we are searching to count string (in our program '\n' is sign of the end of the line);
	int* length   - is length of the buffer;
return - count - number of lines;

createArrayOfStrings - is function that creating an array of number signed to the end of each string;
	char buffer[] 		 - is our buffer getString function contained the text including symdols of the transition to a new line;
	int* length   		 - is length of the buffer;
	int* numberOfStrings - number of strings counted witn countLines function;
	char* text[] 		 - is an array of number signed to the end of each string;
return - only OK;

writeText - is function that opening outputDOWN.txt to print sorted text from begin to end and outputUP.txt for text sorted from end to begin;
	const int direction - UP or DOWN fepended on direction text is sorted;
	char* text[] 		- is an array of number signed to the end of each string;
	int* numberOfLines 	- number of strings counted witn countLines function;
return - ERROR if file could not be opend and OK if it could be opend;

sortText - is function 
	const int direction - FIRST or LAST fepended on direction we want to sort text;
	char* text[] 		- is an array of number signed to the end of each string;
	int* numberOfLines 	- number of strings counted witn countLines function;
return - ERROR as default in switch and OK if it is;

compFirst - is function that we use to compare two string from the beginig of the string using strcmp function;
	const void* a - first string to compare;
	const void* b - second string to compare;
return - as strcmp;

compLast - is function that we use to compare two string from the beginig of the string using strcmpFromEnd function;
	const void* a - first string to compare;
	const void* b - second string to compare;
return - as strcmpFromEnd;

strcmpFromEnd - is function that is equal to function strcmp but this function is comparing last symbols of two strings until they will not be equal;
	const char a[] - last letter in the first string;
	const char b[] - last letter in the second string;

**/

/**
This is our intepritation of fread function combined with closing file;
@param f is file with the text we want to sort;
@param buffer is dynamic array of letters, numbers, and other symbols including a symbol of the transition to a new line;
@param length is the length of input file(length = filelength(fileno(*FILENAME*)));
@return only OK;
*/

int getString(FILE* f, char buffer[], int* length);
int countLines(char buffer[], char symbol, int* length);
int createArrayOfStrings(char buffer[], int* length, int* numberOfStrings, char* text[]);
int writeText(const int direction, char* text[], int* numberOfLines);
int sortText(const int direction, char* text[], int* numberOfLines);
int compFirst(const void* a, const void* b);
int compLast(const void* a, const void* b);
int strcmpFromEnd(const char a[], const char b[]);

int main()
{
	setlocale(LC_ALL, "Russian");
	
	FILE* input  = fopen("INPUT.txt",  "r");
	if (input == NULL)
    {
        printf("ERROR: Can't open the file: 'INPUT.txt'\n");
        system("pause");
        exit(1);
    }

	int length = filelength(fileno(input));
	if (length == 0)
	{
		printf("ERROR: Input file is empty\n");
		system("pause");
		exit(1);
	}

	char* buffer = (char*) calloc(length, sizeof(char));
	assert(buffer != NULL);

	int checkAssert = getString(input, buffer, &length);
	assert(checkAssert == OK);

	int numberOfLines = countLines(buffer, '\n', &length);
	assert(numberOfLines > 0);
	
	char** text = (char**) calloc(numberOfLines, sizeof(char));
    assert(text != NULL);

	checkAssert = createArrayOfStrings(buffer, &length, &numberOfLines, text);
	assert(checkAssert == OK);
	
	checkAssert = sortText(FIRST, text, &numberOfLines);
    assert(checkAssert == OK);

    checkAssert = writeText(DOWN, text, &numberOfLines);
    assert(checkAssert == OK);

    checkAssert = sortText(LAST, text, &numberOfLines);
    assert(checkAssert == OK);

    checkAssert = writeText(UP, text, &numberOfLines);
    assert(checkAssert == OK);

	//system("pause");
}

int getString(FILE* input, char* buffer, int* length)
{
	//opening input file and reading content (all symbals) to buffer and closing input file after all;
    fread(buffer, *length, sizeof(char), input);
    fclose(input);
    return OK;
}

int countLines(char buffer[], char symbol, int* length)
{
	//counting number of lines by searching an anchor symbol ('\n');
	int count = 0;
	for (int i = 0; i < *length; i++)
	{
		if (buffer[i] == symbol)
			count++;
		if ((i == (*length - 1)) && (buffer[i] != symbol))
		{
			count++;
		}
	}
	return count;
}

int createArrayOfStrings(char buffer[], int* length, int* numberOfLines, char* text[])
{
	int j = 0, firstLatter = 0;
	for (int i = 0; i < *numberOfLines; i++)
	{
		while ((j < *length) && (buffer[j] != '\n')) j++;
		//replacing symbol '\n' with '\0' means that the end of line is becoming the end of string;
		buffer[j] = '\0';
		text[i] = &buffer[firstLatter];
		firstLatter = ++j;
	}

	return OK;
}

int writeText(const int direction, char* text[], int* numberOfLines)
{
	//checking if function arguments are correct and choosing which file to open for recording: 'outputDOWN' or 'outputUP';
	assert(direction == DOWN || direction == UP);
	FILE* output = NULL;
	switch (direction)
	{
	case DOWN:
		output = fopen("outputDOWN.txt", "w");
		if (output == NULL)
		{
			printf("ERROR: Can't open the file: 'outputDOWN.txt'\n");
			system("pause");
			exit(1);
		}
		break;
	case UP:
		output = fopen("outputUP.txt", "w");
		if (output == NULL)
		{
			printf("ERROR: Can't open the file: 'outputUP.txt'\n");
			system("pause");
			exit(1);
		}
		break;
	default:
		return ERROR;
		break;
		}

	//printing of all string in opend file;
	for (int i = 0; i < *numberOfLines; i++)
			{
				fprintf(output, "%s\n", text[i]);
			}
	//checking if we did previous move and recorded output file and closing this file;
	assert(output != NULL);
	fclose(output);
	return OK;
}

int sortText(const int direction, char* text[], int* numberOfLines)
{
	//checking if function arguments are correct and choosing how to sort text: from the begin to end, or reverse;
    assert(direction == FIRST || direction == LAST);
    switch (direction)
    {
        case FIRST:
            qsort(text, *numberOfLines, sizeof(text[0]), compFirst);
            break;
        case LAST:
            qsort(text, *numberOfLines, sizeof(text[0]), compLast);
            break;
        default:
            return ERROR;
            break;
    }

    return OK;
}

int compFirst(const void* a, const void* b)
{
	//comparing two strings by first symbols;
	return strcmp(*(const char**)a, *(const char**)b);
}

int compLast(const void* a, const void* b)
{
	//comparing two strings by last;
	return strcmpFromEnd(*(const char**)a, *(const char**)b);
}

int strcmpFromEnd(const char a[], const char b[])
{	
    int aLength = strlen(a), bLength = strlen(b);
    aLength--;
    bLength--;

    while (aLength && bLength)
    {
        if ((unsigned char) a[aLength] > (unsigned char) b[bLength]) return true;
            else if ((unsigned char) a[aLength] < (unsigned char) b[bLength]) return false;
                else aLength--, bLength--;
    }

    return (aLength) ? true : false;
}