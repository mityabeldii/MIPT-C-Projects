const char CODE_PUSH = 1;
const char CODE_PUSH_AX = 76;
const char CODE_POP = 4;
const char CODE_ADD = 2;
const char CODE_DUMPST = 5;
const char CODE_END = 3;
const char CODE_MUL = 7;

const char GROUP_PUSH = 1;
const char GROUP_ADD = 0;
const char GROUP_END = 0;
const char GROUP_POP = 0;
const char GROUP_DUMPST = 0;
const char GROUP_PUSH_AX = 0;
const char GROUP_MUL = 0;