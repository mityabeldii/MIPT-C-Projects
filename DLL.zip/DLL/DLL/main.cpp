/**
> name		> DLL
> file		> main.cpp
> authors	> Mitya Beldii, GROUP 672, MIPT
> date		> NOVEMBER 28, 2016
> version	> 2.0
**/

#include <iostream>
#include <cassert>
using namespace std;
const int OK = 1, ERROR = -1, before = -1, current = 0, after = 1;

/*
OK 		- is using to check if function work correctle;
ERROR 	- is using to check if function does not work correctle;
before 	- is using to insert node before neighbourNode and to delete node before neighbourNode;
after 	- is using to insert node after neighbourNode and to delete node after neighbourNode;
current - is using to delete current element;
*/

struct node
{
	int data;
	node* prev;
	node* next;
};

//DLL = Doubly Layed List

struct dll
{
	node* first;
	node* last;
};
/*
@function dllNodeCounter
This is support function for @dllNodeNumber which implements a recursive run to the end of the DLL
nodeToCount - current countable node
nodeCount 	- counter
*/
int dllNodeCounter(node* nodeToCount, int nodeCount);
/*
@function dllNodeNumber
This function returns number of nodes in the DLL
dllToCount - DLL we want to count
*/
int dllNodeNumber(dll* dllToCount);
/*
@function nodeSearcher
This is support function for @nodeByNumber which implements a recursive run to the end of the DLL until it finde a node
nodeToSearch 	- current comparable node
currentNumber 	- number of current node
numberToSearch 	- number we searching
returns a link of the sought-for node
*/
node* nodeSearcher(node* nodeToSearch, int currentNumber, int numberToSearch);
/*
@function nodeByNumber
This function is searching a node by its' number un the DLL
dllToSearch 	- DLL that contains sought-for node
numberToSearch 	- number of node we want to find
returns a link of the sought-for node
*/
node* nodeByNumber(dll* dllToSearch, int numberToSearch);
/*
@function printNode
This is support function for @dumpDll which implements a recursive run to the end of the DLL and print each node
nodeToPrint - current node to print
nodeNumber 	- current node number (also prints)
*/
int  printNode(node* nodeToPrint, int nodeNumber);
/*
@function dumpDll
This dump function that print all detail about DLL
dllToDump - DLL we want to dump
return OK
*/
int dumpDll(dll* dllToDump);
/*
@function checkNeighbours
This is support function for @checkLastLink to check if current nodes neighbout (if the are exist) are related with him
nodeToCheck - node we are checking
return OK or ERROR
*/
int checkNeighbours(node* nodeToCheck);
/*
@function checkFirstLink
This is support function for @checkLastLink that runs from the end of the DLL to the beginingand and checking if the
biginig is equal dll.first
dllToCheck - DLL we are checking
nodeToCheck - current node of the run
return OK or ERROR
*/
int checkFirstLink(dll* dllToCheck, node* nodeToCheck);
/*
@function checkLastLink
This is support function for @checkLastLink that runs from the begining of the DLL to the end and checking if the
biginig is equal dll.first
dllToCheck - DLL we are checking
nodeToCheck - current node of the run
return OK or ERROR
*/
int checkLastLink(dll* dllToCheck, node* nodeToCheck);
/*
@function checkLastLink
This is function to check correctness of all reletions between all neighbour nodes and DLL and nodes
dllToCheck - DLL we are checking
return OK or ERROR
*/
int checkCorrectness(dll* dllToCheck);
/*
@function nodeInsert
This is function to insert node in the DLL
nodeToInsert 	- inserting node
dllToInsert 	- DLL to insert this node
determinator 	- determinator to show the position relatively to neighbourNode
determinator = { before, after };
neighbourNode 	- is node node after or befor which we want to insert node
return OK;
*/
int nodeInsert(node* nodeToInsert, dll* dllToInsert, int determinator, node* neighbourNode);
/*
@function nodeDelete
This is function to delete node from the DLL
dllToDelete 	- DLL to delete node
determinator 	- determinator to show the position relatively to neighbourNode
determinator = { before, current, after };
neighbourNode 	- is node node after which, befor which or which we want to delete
return OK;
NOTE!
IF THE LIST IS EMPTY - FUNCTION WILL INSERT ONE NODE INTO IT AND IT NOT DEPENDS ON DETERMINATOR
*/
int nodeDelete(dll* dllToDelete, int determinator, node* neighbourNode);
/*
@function dllCounstruct
This is constructor of the DLL which fill with NULL values
dllToConstruct - is DLL we want to initialize;
return OK;
*/
int dllCounstruct(dll* dllToConstruct);
/*
@function dllDestruct
This is constructor of the DLL which delete all nodes in the lst and fill it with NULL values
dllToDestruct - is DLL we want to destruct;
return OK;
*/

int dllDestruct(dll* dllToDestruct);


int main()
{
	dll dll_1 = { NULL, NULL };
	dllCounstruct(&dll_1);

	node node_1 = { 1, NULL, NULL };
	node node_2 = { 2, NULL, NULL };
	node node_3 = { 3, NULL, NULL };
	assert(nodeInsert(&node_1, &dll_1, after, dll_1.last) == OK);
	assert(nodeInsert(&node_2, &dll_1, after, dll_1.last) == OK);
	assert(nodeInsert(&node_3, &dll_1, after, dll_1.last) == OK);

	int nodeNumber = 2;
	nodeDelete(&dll_1, current, nodeByNumber(&dll_1, nodeNumber));

	dumpDll(&dll_1);
	assert(checkCorrectness(&dll_1) == OK);
	dllDestruct(&dll_1);
	system("pause");
	return 0;
}

int dllNodeCounter(node * nodeToCount, int nodeCount)
{
	assert(nodeToCount != NULL);
	nodeCount++;
	if (nodeToCount->next != NULL)
		return dllNodeCounter(nodeToCount->next, nodeCount);
	return nodeCount;
}

int dllNodeNumber(dll * dllToCount)
{
	assert(&dllToCount != NULL);
	assert(checkCorrectness(dllToCount) == OK);
	int nodeNumber = 0;
	if (dllToCount->first == NULL)
		return 0;
	else
		return dllNodeCounter(dllToCount->first, nodeNumber);
	return OK;
}

node * nodeSearcher(node * nodeToSearch, int currentNumber, int numberToSearch)
{
	assert(&nodeToSearch != NULL);
	currentNumber++;
	if (numberToSearch != currentNumber)
		return nodeSearcher(nodeToSearch->next, currentNumber, numberToSearch);
	return nodeToSearch;
}

node * nodeByNumber(dll * dllToSearch, int numberToSearch)
{
	assert(&dllToSearch->first != NULL);
	assert((numberToSearch > 0) && (numberToSearch <= dllNodeNumber(dllToSearch)));
	int currentNumber = 0;
	return nodeSearcher(dllToSearch->first, currentNumber, numberToSearch);
}

int printNode(node * nodeToPrint, int nodeNumber)
{
	assert(&nodeToPrint != NULL);
	nodeNumber++;
	cout << "-----" << endl;
	cout << "node #" << nodeNumber << endl;
	cout << "link " << nodeToPrint << endl;
	cout << "data " << nodeToPrint->data << endl;
	cout << "prev " << nodeToPrint->prev << endl;
	cout << "next " << nodeToPrint->next << endl;
	cout << "-----" << endl;
	if (nodeToPrint->next != NULL)
		printNode(nodeToPrint->next, nodeNumber);
	return OK;
}

int dumpDll(dll * dllToDump)
{
	assert(checkCorrectness(dllToDump) == OK);
	assert(&dllToDump != NULL);
	int nodeNumber = 0;
	cout << " >> dump begin" << endl;
	cout << "number of nodes: " << dllNodeNumber(dllToDump) << endl;
	cout << "first node: " << dllToDump->first << endl;
	cout << "last node: " << dllToDump->last << endl;
	if (dllToDump->first == NULL)
	{
		cout << " >> dump end" << endl << endl;
		return OK;
	}
	printNode(dllToDump->first, nodeNumber);
	cout << " >> dump end" << endl << endl;
	return OK;
}

int checkNeighbours(node * nodeToCheck)
{
	assert(&nodeToCheck != NULL);
	if (nodeToCheck->next != NULL)
		if (nodeToCheck->next->prev != nodeToCheck)
			return ERROR;
	if (nodeToCheck->prev != NULL)
		if (nodeToCheck->prev->next != nodeToCheck)
			return ERROR;
	if (nodeToCheck->next != NULL)
		return(checkNeighbours(nodeToCheck->next));
	return OK;
}

int checkFirstLink(dll * dllToCheck, node * nodeToCheck)
{
	assert(&dllToCheck != NULL);
	assert(&nodeToCheck != NULL);
	if (nodeToCheck->prev != NULL)
		return checkFirstLink(dllToCheck, nodeToCheck->prev);
	if (nodeToCheck->prev == NULL)
		if (nodeToCheck != dllToCheck->first)
			return ERROR;
	return OK;
}

int checkLastLink(dll * dllToCheck, node * nodeToCheck)
{
	assert(&dllToCheck != NULL);
	assert(&nodeToCheck != NULL);
	if (nodeToCheck->next != NULL)
		return checkLastLink(dllToCheck, nodeToCheck->next);
	if (nodeToCheck->next == NULL)
		if (nodeToCheck != dllToCheck->last)
			return ERROR;
	return OK;
}

int checkCorrectness(dll * dllToCheck)
{
	assert(&dllToCheck != NULL);
	if (dllToCheck->first != NULL)
		assert(checkNeighbours(dllToCheck->first) == OK);
	if (dllToCheck->last != NULL)
		assert(checkFirstLink(dllToCheck, dllToCheck->last) == OK);
	if (dllToCheck->first != NULL)
		assert(checkLastLink(dllToCheck, dllToCheck->first) == OK);
	return OK;
}

int nodeInsert(node * nodeToInsert, dll * dllToInsert, int determinator, node * neighbourNode)
{
	assert((determinator == before) || (determinator == after));
	assert(dllToInsert != NULL);
	if ((dllToInsert->first == NULL) && (dllToInsert->last == NULL))
	{
		dllToInsert->first = nodeToInsert;
		dllToInsert->last = nodeToInsert;
		return checkCorrectness(dllToInsert);
	}
	if (determinator == after)
	{
		if (dllToInsert->last = neighbourNode)
			dllToInsert->last = nodeToInsert;
		if (neighbourNode->next != NULL)
		{
			neighbourNode->next->prev = nodeToInsert;
			nodeToInsert->next = neighbourNode->next;
		}
		nodeToInsert->prev = neighbourNode;
		neighbourNode->next = nodeToInsert;
		return checkCorrectness(dllToInsert);
	}
	if (determinator == before)
	{
		if (dllToInsert->first = neighbourNode)
			dllToInsert->first = nodeToInsert;
		if (neighbourNode->prev != NULL)
		{
			neighbourNode->prev->next = nodeToInsert;
			nodeToInsert->prev = neighbourNode->prev;
		}
		nodeToInsert->next = neighbourNode;
		neighbourNode->prev = nodeToInsert;
	}
	return ERROR;
}

int nodeDelete(dll * dllToDelete, int determinator, node * neighbourNode)
{
	assert((determinator == before) || (determinator == after) || (determinator == current));
	assert(&dllToDelete != NULL);
	if (determinator == current)
	{
		assert(neighbourNode != NULL);
		if (neighbourNode == dllToDelete->last)
			dllToDelete->last = neighbourNode->prev;
		if (neighbourNode == dllToDelete->first)
			dllToDelete->first = neighbourNode->next;
		if (neighbourNode->next != NULL)
			neighbourNode->next->prev = neighbourNode->prev;
		if (neighbourNode->prev != NULL)
			neighbourNode->prev->next = neighbourNode->next;
		return checkCorrectness(dllToDelete);
	}
	if (determinator == after)
	{
		assert(neighbourNode->next != NULL);
		if (neighbourNode->next == dllToDelete->last)
		{
			dllToDelete->last = neighbourNode;
			neighbourNode->next = NULL;
			return checkCorrectness(dllToDelete);
		}
		if (neighbourNode->next->next != NULL)
			neighbourNode->next->next->prev = neighbourNode;
		neighbourNode->next = neighbourNode->next->next;
		return checkCorrectness(dllToDelete);
	}
	if (determinator == before)
	{
		assert(neighbourNode->prev != NULL);
		if (neighbourNode->prev == dllToDelete->first)
		{
			dllToDelete->first = neighbourNode;
			neighbourNode->prev = NULL;
			return checkCorrectness(dllToDelete);
		}
		if (neighbourNode->prev->prev != NULL)
			neighbourNode->prev->prev->next = neighbourNode;
		neighbourNode->prev = neighbourNode->prev->prev;
		return checkCorrectness(dllToDelete);
	}
	return ERROR;
}

int dllCounstruct(dll * dllToConstruct)
{
	assert(dllToConstruct != NULL);
	dllToConstruct->first = NULL;
	dllToConstruct->last = NULL;
	assert(checkCorrectness(dllToConstruct) == OK);
	return OK;
}

int dllDestruct(dll * dllToDestruct)
{
	assert(dllToDestruct != NULL);
	while (dllToDestruct->first != NULL)
		nodeDelete(dllToDestruct, current, dllToDestruct->first);
	dllToDestruct->first = NULL;
	dllToDestruct->last = NULL;
	assert(checkCorrectness(dllToDestruct) == OK);
	return OK;
}